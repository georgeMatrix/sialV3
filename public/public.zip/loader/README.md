# tutorial-ajax-loader
Como hacer un loader mientras carga una petición AJAX con jQuery

### Tutorial en Youtube
https://youtu.be/e84VCLFF82o
