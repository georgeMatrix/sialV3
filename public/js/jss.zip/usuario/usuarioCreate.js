$(document).ready(function() {
    $("#formUsuario").on('submit', function(){
        $("#guardarUsuario").prop("disabled", true);
    })
});